These sprites were made with Aseprite and are saved in .ase file formats. 
They may or may not be openable in other softwares.

In the folders are sprite sheets for each slime's animations, as well as the .ase files. 
Everything has been made sure to be clearly labeled for easier use.

---------------------------------------------------------------------------

FAQs

- What software was used for these; Can I use other softwares to open them?

WE used Aseprite, although we are not sure if other softwares can open the files.
You can buy Aseprite here: https://www.aseprite.org/

- How do I use the sprite sheets?

A quick YouTube or Google search would be able to explain that better than we can for your respective game engines.

- Can I use these sprites commercially?

Of course.

- Do I need to credit the artist?

No, but you can if you want to.

- Can I sell this on other websites?

No.

- Can I make changes to the sprites?

Sure.

---------------------------------------------------------------------------

If you have any problems with the sprites, contact us at PyroxDev@gmail.com






